import tkinter as tk
from tkinter import messagebox
import joblib

# Load trained model and vectorizer
model = joblib.load('spam_model.pkl')
vectorizer = joblib.load('vectorizer.pkl')

# Predict function
def predict():
    msg = entry.get("1.0", tk.END).strip()
    if not msg:
        messagebox.showwarning("Input Error", "Please enter a message.")
        return
    msg_vector = vectorizer.transform([msg])
    prediction = model.predict(msg_vector)
    result = "Spam ❌" if prediction[0] == 1 else "Not Spam ✅"
    result_label.config(text=f"Prediction: {result}", fg='green' if prediction[0] == 0 else 'red')

# Exit fullscreen on Escape
def exit_fullscreen(event):
    root.attributes('-fullscreen', False)

# GUI setup
root = tk.Tk()
root.title("Spam Detector")
root.configure(bg="#E6E6FA")  # Lavender
root.attributes('-fullscreen', True)
root.bind("<Escape>", exit_fullscreen)

# Container frame to center all widgets
container = tk.Frame(root, bg="#E6E6FA")
container.pack(expand=True)

# Widgets inside the container
title = tk.Label(container, text="📩 Spam Message Detector", font=("Arial", 28, "bold"), bg="#E6E6FA", fg="#4B0082")
title.pack(pady=30)

entry = tk.Text(container, height=10, width=80, font=("Arial", 16), bg="#F8F8FF", fg="black", relief="solid", bd=2)
entry.pack(pady=20)

predict_btn = tk.Button(container, text="Check Spam", command=predict,
                        font=("Arial", 16, "bold"), bg="#9370DB", fg="white",
                        activebackground="#7B68EE", padx=20, pady=10, relief="raised")
predict_btn.pack(pady=10)

result_label = tk.Label(container, text="", font=("Arial", 20, "bold"), bg="#E6E6FA")
result_label.pack(pady=30)

# Run the app
root.mainloop()
